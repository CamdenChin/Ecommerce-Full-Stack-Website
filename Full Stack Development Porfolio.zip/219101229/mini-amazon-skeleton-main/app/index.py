from flask import render_template, redirect, url_for
from flask_login import current_user
import datetime

from .models.product import Product
from .models.sells import Sells
from .models.sellers import Sellers

from flask import Blueprint, request

from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from flask_login import login_user, logout_user, current_user



bp = Blueprint('index', __name__)

class SearchForm(FlaskForm):
    #Seller search
    seller_id = StringField('Enter Seller ID: ')
    submit = SubmitField('Find Products by Seller')

class UserSearchForm(FlaskForm):
    #User search
    user_id = StringField('Enter User ID: ')
    submit = SubmitField('Find User')

class FilterForm(FlaskForm): 
    #Products Guru Search bar
    k_items = StringField('How many items do you want to see?')
    submit = SubmitField('Sort by Price')

class ProductForm(FlaskForm): 
    product_name = StringField('Product Name: ')
    product_category = SelectField('Category: ', choices=[('none', ""), ('Electronics', 'Electronics'), ('Clothing', 'Clothing'), ('Books', 'Books'), ('Sports', 'Sports'), ('Home', 'Home'), ('Beauty', 'Beauty'), ('Toys', 'Toys'), ('Outdoors', 'Outdoors')])
    product_pricesort = SelectField('Sort By: ', choices=[('none', ""), ('highest', 'Descending Price'), ('lowest', 'Ascending Price')])
    product_pricelim = SelectField('Price Limit: ', choices=[('none', ""), ('10', '<$10'), ('100', '<$100'), ('500', '<$500'), ('1000', '<$1000')])
    submit = SubmitField('Search for Product')


# @app.route('/', methods=['POST'])
# def nextPage(): 
#     pagenumber = int(request.form['page'])
#     return pagenumber

def average_review(pid):
        rating = Product.get_average_review(pid)
        if rating: return round(rating, 2)
        else:  return rating

@bp.route('/', methods=['GET', 'POST'])
def index():
    return redirect(url_for('index.index_page', pagenumber=1))

@bp.route('/<int:pagenumber>', methods=['GET', 'POST'])
def index_page(pagenumber):
    # get all available products for sale:
    # products = Product.get_all(True)
    name = request.args.get('product_name', default="")
    category = request.args.get('product_category', default="")
    pricesort = request.args.get('product_pricesort', default="")
    pricelim = request.args.get('product_pricelim', default="")

    if pricesort == "highest":
        pricesort = "DESC"
    elif pricesort == "lowest":
        pricesort = "ASC"

    if pricelim and pricelim != 'none': 
        pricelim = int(pricelim)

    products = Product.display_k_page(pagenumber, 9, name, category, pricesort, pricelim)

    # variables for our classes
    form = SearchForm()
    userform = UserSearchForm()
    filterform = FilterForm()
    productform = ProductForm(formdata=request.args)

    # Set the data for the ProductForm fields
    productform.product_name.data = name
    productform.product_category.data = category
    productform.product_pricesort.data = 'highest' if pricesort == "DESC" else 'lowest' if pricesort == "ASC" else ""
    productform.product_pricelim.data = str(pricelim) if pricelim else ""

    # Finds product by seller id, redirects to sells url
    if form.seller_id.data:
        seller_id = form.seller_id.data
        
        return redirect(url_for('sells.sells', seller_id=seller_id))

    #finds user by user id, redirects to user public profile url
    if userform.user_id.data:
        user_id = userform.user_id.data

        return redirect(url_for('users.pub_profile', id = user_id))
    

    if filterform.k_items.data: 
        k = filterform.k_items.data

        return redirect(url_for('index.index_k_expensive', k = k)) #Redirects to the bottom function

    seller = False
    if current_user.is_authenticated:
        if Sellers.isSeller(current_user.id):
            seller = True
    
    return render_template('index.html',
                           avail_products=products,
                           form=form, 
                           userform=userform,
                           filterform=filterform,
                           seller=seller,
                           average_review=average_review,
                           productform=productform,
                           pagenumber=pagenumber,
                           name=name,
                           category=category,
                           pricesort=pricesort)

    

    # get the average review for each product
    for product in products:
       product.averagereview = Product.get_average_review(product.id)
       print(product.averagereview)

    # render the page by adding information to the index.html file
    return render_template('index.html',
                           avail_products=products,
                           form=form, 
                           userform=userform,
                           filterform=filterform,
                           seller=seller,
                           average_review=average_review,
                           productform=productform,
                           pagenumber=pagenumber)



@bp.route('/expensive/<int:k>', methods=['POST', 'GET'])
def index_k_expensive(k): 
    products = Product.get_k(k) #only gets the first k items, sorted by price
    return render_template('k_products.html', #new html file
                            avail_products = products)

# @bp.route('/product', methods=['POST', 'GET'])
# def get_product(name, category, pricesort): 
#     name = request.args.get('name', default="")
#     category = request.args.get('category', default="")
#     pricesort = request.args.get('pricesort', default="")
#     name = "%" + name + "%"
#     if pricesort == "highest": 
#         pricesort = "DESC"
#     elif pricesort == "lowest": 
#         pricesort = "ASC"
#     print(pricesort)
#     if(category == ""): 
#         products = Product.get_product(name)
#     elif(pricesort != ""):         
#         products = Product.get_product_with_category_and_price_sorting(name, category, pricesort)
#     return render_template('product_name.html', 
#                             avail_products = products, 
#                             average_review = average_review)
