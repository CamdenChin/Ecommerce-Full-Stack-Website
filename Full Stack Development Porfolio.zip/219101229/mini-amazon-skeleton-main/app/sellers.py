from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for, request, flash
import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField

from .models.sells import Sells
from .models.sellers import Sellers
from .models.product import Product, ProductAnalytics
from .models.sellerhistory import SellerHistory, SellerBuyerAnalytics


from flask import Blueprint
bp = Blueprint('sellers', __name__)
from .models.wishlist import WishlistItem

class InventoryProductEditForm(FlaskForm):
    #Seller search
    quantity = StringField('Quantity')
    submit = SubmitField('Edit Quantity')

class AddProductForm(FlaskForm):
    product_name = StringField('Product Name')
    product_description = StringField('Product Description')
    price = StringField('Price')
    quantity = StringField('Quantity')
    product_category = SelectField('Category: ', choices=[('none', ""), ('Electronics', 'Electronics'), ('Clothing', 'Clothing'), ('Books', 'Books'), ('Sports', 'Sports'), ('Home', 'Home'), ('Beauty', 'Beauty'), ('Toys', 'Toys'), ('Outdoors', 'Outdoors')])
    product_url = StringField('Product Image URL')
    submit = SubmitField('Add Product')

class AddProductByIDForm(FlaskForm):
    product_id = StringField('Product ID')
    price = StringField('Price')
    quantity = StringField('Quantity')
    submit = SubmitField('Add Product')


def is_valid_number(value):
    try:
        float_value = float(value)
        return True
    except ValueError:
        return False



@bp.route('/sellers/<int:page>')
def sellers(page):
    seller = False
    addForm = AddProductForm()
    addIdForm = AddProductByIDForm()
    # return template displaying seller inventory

    offset = (page - 1) * 25

    if current_user.is_authenticated:
        if Sellers.isSeller(current_user.id):
            seller = True
        if not seller:
            return redirect(url_for('index.index'))
        products = Sells.get_all_by_seller_id(
            seller_id=current_user.id,
            page=offset
        )
        
        return render_template('seller_inventory.html',
                    products=products,
                    addForm = addForm,
                    addIdForm = addIdForm,
                    page = page)
    else:
        items = None
        return jsonify({}), 404
        
@bp.route('/sellers/product/<int:product_id>')
def selleredit_product(product_id):
    inventoryForm = InventoryProductEditForm()

    if current_user.is_authenticated:
        product = Sells.get_by_seller_id_and_product_id(current_user.id, product_id)
        return render_template('seller_product_detail.html',
                      product = product,
                      inventoryForm = inventoryForm)
    else:
        # if user not logged in, 404 error
        items = None
        return jsonfiy({}), 404


@bp.route('/sellers/edit', methods=['POST'])
def quantity_edit():
    product_id = request.form.get('product_id')
    seller_id = request.form.get('seller_id')
    quantity = request.form.get('quantity')

    if not quantity.isdigit() or int(quantity) < 0:
        return redirect(url_for('sellers.sellers', page = 1))
        
    # take in product id, seller id, and quantity
    if current_user.is_authenticated:
        Sells.update_quantity_by_seller_id_and_product_id(current_user.id, product_id, quantity)
        # direct to template listing detailed cart view
        return redirect(url_for('sellers.sellers', page = 1))
    else:
        return jsonfiy({}), 404


@bp.route('/sellers/product/delete/<int:product_id>')
def delete_product(product_id):
    if current_user.is_authenticated:
        product = Sells.delete_by_seller_id_and_product_id(current_user.id, product_id)
        return redirect(url_for('sellers.sellers', page = 1))
    else:
        # if user not logged in, 404 error
        items = None
        return jsonfiy({}), 404


@bp.route('/sellers/add_product', methods=['POST'])
def add_product():
    product_name = request.form.get('product_name')
    product_description = request.form.get('product_description')
    product_category = request.form.get('product_category')
    product_url = request.form.get('product_url')
    quantity = request.form.get('quantity')
    price = request.form.get('price')

    if product_name == "" or product_description == "" or product_category == "none" or product_category == "" or product_url == "" or quantity == "" or price == "" or is_valid_number(price) == False or not quantity.isdigit() or int(quantity) < 0:
        flash('Error: Invalid product information specified', 'error')
        return redirect(url_for('sellers.sellers', page = 1))
        
    # take in product id, seller id, and quantity
    if current_user.is_authenticated:
        prod_id = Product.add_product(product_name, product_description, product_category, product_url)
        print('prod id', prod_id)
        if not prod_id:
            flash('Error: Product Name Already Taken', 'error')
            return redirect(url_for('sellers.sellers', page = 1))
        # direct to template listing detailed cart view
        if Sells.add_by_seller_id_and_product_id(current_user.id, prod_id, quantity, price):
            flash('Success: Product Added', 'success')
        else:
            flash('Error: Product Name Already Taken', 'error')
        return redirect(url_for('sellers.sellers', page = 1))
    else:
        return jsonfiy({}), 404

@bp.route('/sellers/add_existing_product', methods=['POST'])
def add_existing_product():
    prod_id = request.form.get('product_id')
    quantity = request.form.get('quantity')
    price = request.form.get('price')

    if not quantity.isdigit() or int(quantity) < 0:
        flash('Error: Invalid quantity specified', 'error')
        return redirect(url_for('sellers.sellers', page = 1))

    # check if price is a valid number
    if is_valid_number(price) == False:
        flash('Error: Invalid price specified', 'error')
        return redirect(url_for('sellers.sellers', page = 1))
        
    # take in product id, seller id, and quantity
    if current_user.is_authenticated: 
        # direct to template listing detailed cart view
        if Sells.add_by_seller_id_and_product_id(current_user.id, prod_id, quantity, round(float(price), 2)):
            flash('Success: Product Added', 'success')
            return redirect(url_for('sellers.sellers', page = 1))
        else:
            flash('Error: Product ID not a Valid Product', 'error')
            return redirect(url_for('sellers.sellers', page = 1))
    else:
        return jsonfiy({}), 404


@bp.route('/sellers/orders/<int:page>')
def seller_orders(page):
    if current_user.is_authenticated:

        offset = (page - 1) * 15

        orders = SellerHistory.get_orderitems_by_seller_id(current_user.id, offset)

        orders_by_id = {}
        for order in orders:
            if order.oid not in orders_by_id:
                orders_by_id[order.oid] = []
            orders_by_id[order.oid].append(order)

        return render_template('seller_order_history.html',
                    orders=orders_by_id,
                    page=page)
    else:
        items = None
        return jsonify({}), 404

@bp.route('/sellers/orders/analytics/<int:buyer_id>')
def seller_orders_analytics(buyer_id):
    if current_user.is_authenticated:
        analytics = SellerBuyerAnalytics.get_analytics(current_user.id, buyer_id)
        return render_template('buyer_analytics.html',
                    data=analytics)
    else:
        items = None
        return jsonify({}), 404


@bp.route('/sellers/orders/fulfill/<int:orderitem_id>')
def fulfill_order(orderitem_id):
    if current_user.is_authenticated:
        SellerHistory.mark_item_fulfilled(orderitem_id)
        return redirect(url_for('sellers.seller_orders', page = 1))
    else:
        items = None
        return jsonify({}), 404


@bp.route('/sellers/productanalytics/<int:product_id>', methods=['GET'])
def product_analytics(product_id):
    if current_user.is_authenticated:
        analytics = ProductAnalytics.get_analytics(
            pid=product_id,
            sid=current_user.id
        )
        print(analytics)
        return render_template('product_analytics.html',
                        data=analytics)
    else:
        product = None
    return jsonify({}), 404