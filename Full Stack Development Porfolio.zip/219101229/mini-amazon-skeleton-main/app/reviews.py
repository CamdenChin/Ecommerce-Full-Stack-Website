from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for
import datetime
from .models.reviews import ReviewItem
from .models.sellerreviewitem import SellerReviewItem
from flask import render_template
from .models.sellers import Sellers
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Length
from flask import request
from flask import flash
from .models.orderitem import OrderItem
from flask import Blueprint
from .models.user import User
from .models.product import Product


bp = Blueprint('reviews', __name__)

class ReviewForm(FlaskForm):
    id = StringField('review_id', validators=[DataRequired(), Length(min=1, max=100)])
    uid = StringField('uid', validators=[DataRequired(), Length(min=1, max=100)])
    sid = StringField('sid', validators=[DataRequired(), Length(min=1, max=100)])
    text = TextAreaField('text', validators=[DataRequired(), Length(min=1, max=500)])
    star = StringField('Amount of Stars:', validators=[DataRequired()])
    submit = SubmitField('submit')

class SellerReviewForm(FlaskForm):
    product = StringField('In regards to your order of', validators=[DataRequired()])
    id = StringField('review_id', validators=[DataRequired(), Length(min=1, max=100)])
    uid = StringField('uid', validators=[DataRequired(), Length(min=1, max=100)])
    sid = StringField('sid', validators=[DataRequired(), Length(min=1, max=100)])
    text = TextAreaField('text', validators=[DataRequired(), Length(min=1, max=500)])
    star = StringField('Amount of Stars:', validators=[DataRequired()])
    submit = SubmitField('submit')

def seller_average_review(sid):
        rating = Sellers.get_average_review(sid)
        if rating: return round(rating, 2)
        else:  return rating

@bp.route('/reviews', methods=['GET', 'POST'])
def reviews():

    # find the products current user has bought:
    if current_user.is_authenticated:
        sellerReviews = SellerReviewItem.get_all_by_uid_since(
        current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))


        reviews = ReviewItem.get_all_by_uid_since(
            current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        return render_template('reviews.html',
                            reviews = reviews,
                            sellerReviews = sellerReviews,
                            get_item_name = get_item_name
                            )
    else:
        reviews = None
    return jsonify({}), 404

def get_item_name(pid):
        return Product.get_product_name(pid)
    


@bp.route('/create_reviews/<pid>/<sid>', methods=['GET', 'POST'])
def create_reviews(pid, sid):
    print(pid, sid)
    uid = current_user.id

    # create an instance of the ReviewForm
    form = ReviewForm()

    # if form.validate_on_submit():
    #     return redirect(url_for('reviews.review_add', pid = pid))

    return render_template('create_reviews.html', form=form, name = get_item_name(pid), pid = pid, sid = sid)

@bp.route('/review_edit/<id>/<pid>/<sid>', methods=['GET', 'POST'])
def review_edit(id, pid, sid):
    form = ReviewForm()
    return render_template('review_edit.html', form=form, id = id, name = get_item_name(pid), pid = pid, sid = sid)

@bp.route('/seller_review_edit/<id>/<pid>/<sid>', methods=['GET', 'POST'])
def seller_review_edit(id, pid, sid):
    form = SellerReviewForm()
    return render_template('seller_review_edit.html', form=form, id = id, name = get_item_name(pid), pid = pid, sid = sid)

@bp.route('/review_delete/<id>', methods=['GET', 'POST'])
def review_delete(id):
    ReviewItem.delete_review(id)
    return redirect(url_for('reviews.reviews'))

@bp.route('/sellerreview_delete/<id>', methods=['GET', 'POST'])    
def sellerreview_delete(id):       
    SellerReviewItem.delete_review(id)
    return redirect(url_for('reviews.reviews'))

@bp.route('/add_seller_feedback/<name>/<sid>', methods=['GET', 'POST'])
def add_seller_feedback(name, sid):
    # Get the current user's ID
    uid = current_user.id

    print(uid, sid)

    # Get the products using the get_all_by_uid_and_sid method
    products = OrderItem.get_all_by_uid_and_sid(uid, sid)
    
    # Print the products
    for product in products:
        print("The name is: " + product.name + ". The id is: " + str(product.id))


    form = SellerReviewForm()
    return render_template('add_seller_feedback.html', form=form, name=name, sid=sid, products=products)


@bp.route('/review_add', methods=['GET', 'POST'])
def review_add():
    if current_user.is_authenticated:
        uid = current_user.id
        sid = request.form.get('sid')
        pid = request.form.get('pid')
        text = request.form.get('text')
        star = request.form.get('star')
        time_added = datetime.datetime.now()
       
        ReviewItem.insert_new_review(current_user.id, pid, sid, text, star, time_added) 
        
     
        return redirect(url_for('reviews.reviews'))
    else:
        return jsonify({}), 404
    

@bp.route('/review_editAdd', methods=['GET', 'POST'])
def review_editAdd():
    if current_user.is_authenticated:
        uid = current_user.id
        id =  request.form.get('id')
        sid = request.form.get('sid')
        pid = request.form.get('pid')
        text = request.form.get('text')
        star = request.form.get('star')
        time_added = datetime.datetime.now()
        print(uid, pid, sid, text, star, time_added)
        print("review added")
        ReviewItem.update_review(id, text, star, time_added)    
        print(uid, pid, sid, text, star, time_added)
        return redirect(url_for('reviews.reviews'))
    else:
        return jsonify({}), 404
    

@bp.route('/sellerreview_editAdd', methods=['GET', 'POST'])
def sellerreview_editAdd():
    if current_user.is_authenticated:
        uid = current_user.id
        id =  request.form.get('id')
        sid = request.form.get('sid')
        pid = request.form.get('pid')
        text = request.form.get('text')
        star = request.form.get('star')
        time_added = datetime.datetime.now()
        print(uid, pid, sid, text, star, time_added)
        print("review added")
        SellerReviewItem.update_review(id, text, star, time_added)    
        print(uid, pid, sid, text, star, time_added)
        return redirect(url_for('reviews.reviews'))
    else:
        return jsonify({}), 404


@bp.route('/review_SellerAdd', methods=['GET', 'POST'])
def review_SellerAdd():
    print("review_SellerAdd() page")
    reviews = ReviewItem.get_all_by_uid_since(
        current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
    

    if current_user.is_authenticated:
        uid = current_user.id
        sid = int(request.form.get('sid')) if request.form.get('sid') else None
        text = request.form.get('text')
        star = request.form.get('star')
        
        product_pid = request.form.get('product')

        time_added = datetime.datetime.now()
        print("Product id is _" + request.form.get('product'))
        SellerReviewItem.insert_new_review(uid, product_pid, sid, text, star, time_added) 
        sellerReviews = SellerReviewItem.get_all_by_sid_since(
        sid, datetime.datetime(1980, 9, 14, 0, 0, 0))

        review_exists = False
        for sellerReview in sellerReviews:
            if SellerReviewItem.does_exist(current_user.id, sellerReview.sid):
                review_exists = True
                break  # No need to check further
        
        if Sellers.isSeller(sid):
            seller = True
        else:
            seller = False

        user = User.get(sid)
        
        return render_template('public_user.html',
                           user=user,
                           sellerReviews = sellerReviews,
                           get_item_name = get_item_name,
                           seller = seller,
                           seller_average_review = seller_average_review,
                           review_exists = review_exists
                           )
    else:
        return jsonify({}), 404
    


    















