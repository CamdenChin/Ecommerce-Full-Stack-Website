from flask import render_template
from flask_login import current_user
from flask import jsonify
import datetime

from .models.reviews import ReviewItem
from .models.order import Order
from .models.orderitem import OrderItem
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField

from flask import Blueprint, redirect, url_for, request
bp = Blueprint('orderitem', __name__)

@bp.route('/orders/analytics', methods=['POST'])
def orders_analytics():
    dt = request.form.get('dt')
    time_dict = {30: "Last Month", 
                 90: "Last 3 Months",
                 180: "Last 6 months",
                 365: "Last Year",
                 1: "All Time"
                 }
    time_breakdown = None
    if not dt:
        # If error, default to orders from today
        date = datetime.datetime.now()-datetime.timedelta(1)
    else:
        dt = int(dt)
        if dt == 1: # All time case  
            date = datetime.datetime.min   
        else:
            date = datetime.datetime.now()-datetime.timedelta(dt)
            time_breakdown = OrderItem.get_time_breakdown_since_from_uid(current_user.id, date)
    print(dt)
    print(date)
    
    if current_user.is_authenticated:
        items = OrderItem.get_since_from_uid(
            current_user.id, date)
        return render_template('order_analytics.html',
                      items=items,
                      time=time_dict[dt],
                      breakdown = OrderItem.get_breakdown_since_from_uid(current_user.id, date),
                      total_spending = OrderItem.get_total_since_from_uid(current_user.id, date),
                      time_breakdown = time_breakdown)
    else:
        items = None
        return jsonify({}), 404

@bp.route('/orders/<int:order_id>')
def order_detail(order_id):
    # return template displaying all cart items for this user
    # Finds product by seller id, redirects to sells url


    if current_user.is_authenticated:
        order = Order.get(order_id)
        items = OrderItem.get_all_from_oid(order_id)
        for item in items:
            item.review_exists = ReviewItem.does_exist(current_user.id, item.pid, item.sid)
            print(item.pid, item.sid, item.review_exists)
        return render_template('order_detail.html',
                    order = order,
                    items = items
                    )
    else:
        # if user not logged in, 404 error
        items = None
        return jsonify({}), 404
   
