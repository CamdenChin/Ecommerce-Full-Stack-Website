from flask import render_template, redirect, url_for, flash, request
from werkzeug.urls import url_parse
from werkzeug.security import generate_password_hash
from flask_login import login_user, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo
from .models.reviews import ReviewItem
from .models.sellerreviewitem import SellerReviewItem
from .reviews import get_item_name
from .models.sellers import Sellers
from .models.giftcards import GiftCards

from .models.user import User
from humanize import naturaltime
import uuid

import datetime

from flask import Blueprint
bp = Blueprint('users', __name__)


class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')

#balance classes
class addToBalance(FlaskForm):
    amount = StringField('Amount')
    submit = SubmitField('Add to Balance')

class subFromBalance(FlaskForm):
    amount = StringField('Amount')
    submit = SubmitField('Withdraw Amount From Balance')

#user editing forms
class emailEditForm(FlaskForm):
    new_email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Submit Changes')

class nameEditForm(FlaskForm):
    new_firstname = StringField('First Name', validators=[DataRequired()])
    new_lastname = StringField('Last Name', validators=[DataRequired()])
    submit = SubmitField('Submit Changes')

class passwordEditForm(FlaskForm):
    new_password = PasswordField('New Password', validators=[DataRequired()])
    new_password2 = PasswordField(
        'Repeat New Password', validators=[DataRequired(),
                                       EqualTo('new_password')])
    submit = SubmitField('Submit Changes')

class AddressEditForm(FlaskForm):
    new_address = StringField('Street Address', validators = [DataRequired()])
    submit = SubmitField('Submit Changes')


#gift cards
class createGiftCard(FlaskForm):
    amount = StringField('Amount')
    submit = SubmitField('Create Gift Card')

class redeemGiftCard(FlaskForm):
    code = StringField('Gift Card Code')
    submit = SubmitField('Redeem to Balance')


def seller_average_review(sid):
        rating = Sellers.get_average_review(sid)
        if rating: return round(rating, 2)
        else:  return rating

class imageEditForm(FlaskForm):
    image = StringField('Link to new profile image. .jpg, .png, and .gif only', validators=[DataRequired()])
    submit = SubmitField('Submit Changes')

@bp.route('/user/<int:id>', methods=['GET', 'POST'])
def pub_profile(id):
    user = User.get(id)
    sid = id

    sellerReviews = SellerReviewItem.get_all_by_sid_since(
        sid, datetime.datetime(1980, 9, 14, 0, 0, 0))
    review_count = SellerReviewItem.get_seller_rating_count(sid)

    print('review count', review_count)
    if current_user.is_authenticated:
        review_exists = False
        for sellerReview in sellerReviews:
            if SellerReviewItem.does_exist(current_user.id, sellerReview.sid):
                review_exists = True
                break  # No need to check further
    else:
        review_exists = False
    
    if Sellers.isSeller(id):
        seller = True
    else:
        seller = False

    return render_template('public_user.html',
                           user=user,
                           sellerReviews = sellerReviews,
                           get_item_name = get_item_name,
                           seller = seller,
                           review_exists = review_exists,
                           seller_average_review = seller_average_review, 
                           review_count = review_count)

@bp.route('/userprofile')
def profile():
    user = current_user
    addForm = addToBalance()
    subForm = subFromBalance()
    cardForm = createGiftCard()
    redeemCardForm = redeemGiftCard()

    giftCards = GiftCards.get_by_sender_id(current_user.id)

    return render_template('user_profile.html',
                           user=user,
                           addForm = addForm,
                           subForm = subForm,
                           cardForm = cardForm,
                           redeemCardForm = redeemCardForm,
                           currBalance = current_user.balance,
                           giftCards = giftCards,
                           )

@bp.route('/userprofile/addgc', methods=['POST'])
def add_giftcard():
    amount = request.form.get('amount')
    if not amount or not amount.isnumeric() or int(amount) <= 0:
        print('invalid')
        return redirect(url_for('users.profile'))
    amount = float(amount)

    if current_user.is_authenticated:
        if amount <= current_user.balance:
            GiftCards.create_giftcard(str(uuid.uuid4()), amount, False, current_user.id)
        return redirect(url_for('users.profile'))
    else:
        return jsonfiy({}), 404

@bp.route('/userprofile/redeem', methods=['POST'])
def redeem_giftcard():
    code = request.form.get('code')

    if current_user.is_authenticated:
        if GiftCards.redeem_giftcard(code, current_user.id) == False:
            return redirect(url_for('users.profile'))
        return redirect(url_for('users.profile'))
    else:
        return jsonfiy({}), 404

@bp.route('/userprofile/add', methods=['POST'])
def quantity_edit():
    amount = request.form.get('amount')
        
    if current_user.is_authenticated:
        User.edit_balance(amount, current_user.id)
        return redirect(url_for('users.profile'))
    else:
        return jsonfiy({}), 404

@bp.route('/userprofile/sub', methods=['POST'])
def quantity_edit_sub():
    amount = request.form.get('amount')
    amount = float(amount)
    amount = -amount
        
    if current_user.is_authenticated:
        if (float(current_user.balance) + amount) < 0:
            return redirect(url_for('users.balanceerror'))
        else:
            User.edit_balance(amount, current_user.id)
        return redirect(url_for('users.profile'))
    else:
        return jsonfiy({}), 404
    
@bp.route('/balanceerror')
def balanceerror():
    if current_user.is_authenticated:
        return render_template('error_balance.html')
    else:
        return jsonify({}), 404

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index.index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.get_by_auth(form.email.data, form.password.data)
        if user is None:
            flash('Invalid email or password')
            return redirect(url_for('users.login'))
        login_user(user)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index.index')

        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)

#editing user info
@bp.route('/edit-name', methods=['GET', 'POST'])
def editName(userid = None):
    nameForm = nameEditForm()
    userid = current_user.get_id()
    if nameForm.validate_on_submit():
        User.editUserName(id=userid, firstname=nameForm.new_firstname.data, lastname=nameForm.new_lastname.data)
        if nameForm.new_firstname.data and nameForm.new_lastname.data:
            return redirect(url_for('users.profile'))
    return render_template('edit_name.html', nameForm=nameForm)

@bp.route('/edit-email', methods=['GET', 'POST'])
def editEmail(userid = None):
    eForm = emailEditForm()
    userid = current_user.get_id()
    if eForm.validate_on_submit():
        if User.email_exists(eForm.new_email.data):
            return render_template('error_email.html')
        User.editUserEmail(id=userid, email=eForm.new_email.data)
        if eForm.new_email.data:
            return redirect(url_for('users.profile'))            
    return render_template('change_email.html', eForm = eForm)

@bp.route('/edit-address', methods=['GET', 'POST'])
def editAddress(userid = None):
    aForm = AddressEditForm()
    userid = current_user.get_id()
    if aForm.validate_on_submit():
        User.editUserAddress(id=userid, address= aForm.new_address.data)
        if aForm.new_address.data:
            return redirect(url_for('users.profile'))
    return render_template('change_address.html', aForm = aForm)

@bp.route('/edit-password', methods=['GET', 'POST'])
def editPassword(userid = None):
    pwForm = passwordEditForm()
    userid = current_user.get_id()

    if pwForm.validate_on_submit():
        if pwForm.new_password.data != pwForm.new_password2.data:
            flash('Passwords do not match!')
            return redirect(url_for('users.editPassword'))
        else:
            User.editUserPassword(id=userid, password=generate_password_hash(pwForm.new_password.data))
            if pwForm.new_password.data and pwForm.new_password2.data:
                return redirect(url_for('users.profile'))
    return render_template('change_password.html', pwForm = pwForm)

@bp.route('/edit-pfp', methods=['GET', 'POST'])
def editImage(userid = None):
    error = None
    eForm = imageEditForm()
    userid = current_user.get_id()
    if eForm.validate_on_submit():
        User.editUserImage(id=userid, image=eForm.image.data)
        print("here")
        if eForm.image.data:
            return redirect(url_for('users.profile'))
        else:
            error = "You did not submit a link to a valid image type"
    return render_template('change_image.html', eForm = eForm, error=error)

class RegistrationForm(FlaskForm):
    firstname = StringField('First Name', validators=[DataRequired()])
    lastname = StringField('Last Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    address = StringField('Address', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField(
        'Repeat Password', validators=[DataRequired(),
                                       EqualTo('password')])
    submit = SubmitField('Register')

    def validate_email(self, email):
        if User.email_exists(email.data):
            raise ValidationError('Already a user with this email.')


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index.index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        if User.register(form.email.data,
                         form.password.data,
                         form.firstname.data,
                         form.lastname.data,
                         form.address.data):
            flash('Congratulations, you are now a registered user!')
            return redirect(url_for('users.login'))
    return render_template('register.html', title='Register', form=form)


@bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index.index'))

def humanize_time(dt):
    return naturaltime(datetime.datetime.now() - dt)
