from flask import current_app as app
class SellerReviewItem:
    def __init__ (self, id, uid, pid, sid, text, star, time_added):
        self.id = id
        self.uid = uid
        self.pid = pid
        self.sid = sid
        self.text = text
        self.star = star
        self.time_added = time_added


    @staticmethod
    def insert_new_review(uid, pid, sid, text, star, time_added):
        try:
            rows = app.db.execute("""
INSERT INTO SellerReviews(uid, pid, sid, text, star, time_added)
VALUES(:uid, :pid, :sid, :text, :star, :time_added)
RETURNING id
""",
                                uid=uid,
                                pid=pid,
                                sid=sid,
                                text=text,
                                star=star,
                                time_added=time_added)
            id = rows[0][0]
            return SellerReviewItem(id, uid, pid, sid, text, star, time_added)
        except Exception as e:
            print(str(e))
            return None
    
    @staticmethod
    def get_all_by_sid_since(sid, since):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM SellerReviews
WHERE sid = :sid
AND time_added >= :since
ORDER BY time_added DESC;
''',
                              sid=sid,
                              since=since)
        return [SellerReviewItem(*row) for row in rows]
    
    @staticmethod
    def get_seller_rating_count(sid):
        rows = app.db.execute('''
SELECT COUNT(*)
FROM Reviews
WHERE sid = :sid;
''',
                              sid=sid)
        return rows[0][0]
    

    @staticmethod
    def does_exist(uid, sid):
        print(f"Checking existence for uid={uid}, sid={sid}")  # Debug print
        try:
            result = app.db.execute("""
SELECT * FROM SellerReviews
WHERE uid = :uid AND sid = :sid
LIMIT 1
""",
                            uid=uid,
                            sid=sid)
            if result:
                print(f"Review exists: {result[0]}")  # Debug print
                return True
            else:
                print("No matching review found")  # Debug print
                return False
        except Exception as e:
            print(str(e))
            return False
        
    @staticmethod
    def get_all_by_uid_since(uid, since):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM SellerReviews
WHERE uid = :uid
AND time_added >= :since
ORDER BY time_added DESC
LIMIT 5;
''',
                              uid=uid,
                              since=since)
        return [SellerReviewItem(*row) for row in rows]
    
    @staticmethod
    def update_review(id, text, star, time_added):
        try:
            app.db.execute("""
UPDATE SellerReviews
SET text = :text, star = :star, time_added = :time_added
WHERE id = :id
    """,
                        id=id,
                        text=text,
                        star=star,
                        time_added=time_added)
            return SellerReviewItem.get(id)
        except Exception as e:
            print(str(e))
            return None
    
    @staticmethod
    def delete_review(id):
        try:
            app.db.execute("""
DELETE FROM SellerReviews
WHERE id = :id
""",
                    id=id)
            app.db.commit()
            return True
        except Exception as e:
            print(str(e))