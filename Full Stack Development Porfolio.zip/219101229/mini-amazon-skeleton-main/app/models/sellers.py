from flask import current_app as app


class Sellers:
    def __init__(self, id, user_id, average_ratings):
        self.id = id
        self.user_id = user_id
        self.average_ratings = average_ratings

    # Checks if a user is a seller
    @staticmethod
    def isSeller(uid):
        rows = app.db.execute('''
SELECT *
FROM Sellers s
WHERE s.user_id = :uid;
''',
                            uid=uid)
        return [Sellers(*row) for row in rows]
    

    @staticmethod
    def get_average_review(sid):
        try:
            rows = app.db.execute("""
    SELECT AVG(star) FROM SellerReviews WHERE sid = :sid
    """,
                sid=sid)
            return rows[0][0]
        except Exception as e:
            print(str(e))
        return None