from flask import current_app as app


class Sells:
    def __init__(self, seller_id, pid, quantity, name, price, sold=None):
        self.seller_id = seller_id
        self.pid = pid
        self.quantity = quantity
        self.name = name
        self.price = price
        self.sold = sold
        

    def get_all():
        rows = app.db.execute('''
SELECT s.seller_id, s.pid, s.quantity, p.name, s.price
FROM Sells s
JOIN Products p ON s.pid = p.id;
''')
        print(rows)
        return [Sells(*row) for row in rows]

    # Get all products for sale by seller id
    @staticmethod
    def get_all_by_seller_id(seller_id, page):
        rows = app.db.execute('''
SELECT 
    s.seller_id, 
    s.pid, 
    s.quantity, 
    p.name, 
    s.price,
    SUM(oi.qty) AS sold
FROM Sells s
JOIN Products p ON s.pid = p.id
LEFT JOIN OrderItems oi ON s.pid = oi.pid AND s.seller_id = oi.sid
WHERE s.seller_id = :seller_id
GROUP BY s.seller_id, s.pid, s.quantity, p.name, s.price
LIMIT 25 OFFSET :page;

''',
                              seller_id=seller_id,
                              page = page)
        return [Sells(*row) for row in rows]


    # Get a product for sale by seller id and product id
    @staticmethod
    def get_by_seller_id_and_product_id(seller_id, product_id):
        row = app.db.execute('''
SELECT s.seller_id, s.pid, s.quantity, p.name, s.price
FROM Sells s
JOIN Products p ON s.pid = p.id
WHERE s.seller_id = :seller_id AND s.pid = :product_id
LIMIT 1;
''',
                             seller_id=seller_id,
                             product_id=product_id)
        if row is None:
            return None
        elem = row[0]
        return Sells(*elem)


    # Get a product for sale by seller id and product id
    @staticmethod
    def get_by_product_id(product_id):
        rows = app.db.execute('''
SELECT s.seller_id, s.pid, s.quantity, p.name, s.price
FROM Sells s
JOIN Products p ON s.pid = p.id
WHERE s.pid = :product_id;
''',
                             product_id=product_id)
        if rows is None:
            return None
        return [Sells(*row) for row in rows]

    # Update a product quantity by product id and seller id
    @staticmethod
    def update_quantity_by_seller_id_and_product_id(seller_id, product_id, quantity):
        app.db.execute('''
UPDATE Sells
SET quantity = :quantity
WHERE seller_id = :seller_id AND pid = :product_id;
''',
                       seller_id=seller_id,
                       product_id=product_id,
                       quantity=quantity)
        return True
    
    # Update a product quantity by product id and seller id
    @staticmethod
    def submit_order_by_seller_id_and_product_id(seller_id, product_id, stock):
        app.db.execute('''
UPDATE Sells
SET quantity = quantity - :stock
WHERE seller_id = :seller_id AND pid = :product_id;
''',
                       seller_id=seller_id,
                       product_id=product_id,
                       stock=stock)
        return True


    # Delete a product by seller id and product id
    @staticmethod
    def delete_by_seller_id_and_product_id(seller_id, product_id):
        try:
            app.db.execute('''
    DELETE FROM Sells
    WHERE seller_id = :seller_id AND pid = :product_id;
    ''',
                        seller_id=seller_id,
                        product_id=product_id)
            return True
        except:
            return False

    # Add a product by seller id and product id
    @staticmethod
    def add_by_seller_id_and_product_id(seller_id, product_id, quantity, price):
        try:
            app.db.execute('''
    INSERT INTO Sells (seller_id, pid, quantity, price)
    VALUES (:seller_id, :product_id, :quantity, :price);
    ''',
                        seller_id=seller_id,
                        product_id=product_id,
                        quantity=quantity,
                        price=price)
            return True
        except:
            return False