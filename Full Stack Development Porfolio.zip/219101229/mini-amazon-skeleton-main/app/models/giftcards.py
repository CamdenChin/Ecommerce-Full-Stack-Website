from flask import current_app as app


class GiftCards:
    def __init__(self, id, cardNumber, balance, redeemed, sender_id):
        self.id = id
        self.cardNumber = cardNumber
        self.balance = balance
        self.redeemed = redeemed
        self.sender_id = sender_id

    @staticmethod
    def get_by_sender_id(id):
        rows = app.db.execute('''
SELECT id, cardNumber, balance, redeemed, sender_id
FROM GiftCards
WHERE sender_id = :sender_id
''',
                              sender_id=id)
        return [GiftCards(*row) for row in rows]

    @staticmethod
    def create_giftcard(cardNumber, balance, redeemed, sender_id):
        app.db.execute('''
INSERT INTO GiftCards(cardNumber, balance, redeemed, sender_id)
VALUES (:cardNumber, :balance, False, :sender_id)
''',
                       cardNumber=cardNumber,
                       balance=balance,
                       sender_id=sender_id)
        
        app.db.execute('''
        UPDATE Users
        SET balance = balance - :balance
        WHERE id = :id
        ''',
                       balance=balance,
                       id=sender_id)

        return True

    @staticmethod
    def redeem_giftcard(cardNumber, receipient_id):
        card = app.db.execute('''
        SELECT id, cardNumber, balance, redeemed, sender_id
        FROM GiftCards
        WHERE cardNumber = :cardNumber
        ''',
                              cardNumber=cardNumber)
        if not card:
            return False
        card = card[0]
        card = GiftCards(*card)
        if card.redeemed:
            return False

        app.db.execute('''
        UPDATE GiftCards
        SET redeemed = True
        WHERE cardNumber = :cardNumber
        ''',
                       cardNumber=cardNumber)
        
        app.db.execute('''
        UPDATE Users
        SET balance = balance + :balance
        WHERE id = :id
        ''',
                       balance=card.balance,
                       id=receipient_id)

        return True
        