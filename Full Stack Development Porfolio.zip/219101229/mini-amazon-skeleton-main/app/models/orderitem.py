from flask import current_app as app


class OrderItem:
    def __init__(self, id, oid, uid, sid, pid, qty, final_price, status, name):
        self.id = id
        self.oid = oid
        self.uid = uid
        self.sid = sid # seller id
        self.pid = pid
        self.qty = qty
        self.final_price = final_price
        self.status = status
        self.name = name

# Returns full product info of single order item using item id
    @staticmethod
    def get(id):
        rows = app.db.execute('''
SELECT OrderItems.id, oid, uid, sid, pid, qty, final_price, status, name
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
WHERE OrderItems.id = :id 
''',
                              id=id)
        return OrderItem(*(rows[0])) if rows else None

    @staticmethod
    def get_order_status(oid):
        for item in OrderItem.get_all_from_oid(oid):
            if item.status != "fulfilled":
                return "Not Fulfilled"
        return "Fulfilled"

    @staticmethod
    def get_all_from_oid(oid):
        rows = app.db.execute('''
SELECT OrderItems.id, oid, uid, sid, pid, qty, final_price, status, name
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
WHERE OrderItems.oid = :oid 
''',
                              oid=oid)
        return [OrderItem(*row) for row in rows]
    
    @staticmethod
    def get_all_by_uid_and_sid(uid, sid):
        rows = app.db.execute('''
SELECT OrderItems.id, oid, uid, sid, pid, qty, final_price, status, name
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
WHERE OrderItems.uid = :uid AND OrderItems.sid = :sid
    ''',
                            uid=uid,
                            sid=sid)
        return [OrderItem(*row) for row in rows]
    
    @staticmethod
    def get_since_from_uid(uid, date):
        rows = app.db.execute('''
SELECT OrderItems.id, oid, OrderItems.uid, sid, pid, qty, final_price, status, name
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
        JOIN Orders on Orders.id = OrderItems.oid                 
WHERE OrderItems.uid = :uid AND Orders.time_ordered > :date
                              ORDER BY final_price DESC
''',
                              uid=uid, date=date)
        return [OrderItem(*row) for row in rows]

    @staticmethod
    def get_total_since_from_uid(uid, date):
        rows = app.db.execute('''
SELECT sum(final_price)
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
        JOIN Orders on Orders.id = OrderItems.oid                 
WHERE OrderItems.uid = :uid AND Orders.time_ordered > :date
''',
                              uid=uid, date=date)
        return rows[0][0]

    @staticmethod
    def get_breakdown_since_from_uid(uid, date):
        rows = app.db.execute('''
SELECT sum(final_price), category
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
        JOIN Orders on Orders.id = OrderItems.oid                 
WHERE OrderItems.uid = :uid AND Orders.time_ordered > :date
                              GROUP BY category;
''',
                              uid=uid, date=date)
        ret = [['category','total']]
        # Format for chart
        for row in rows:
            ret.append([row[1], float(row[0])])
        print(ret)
        return ret

    # CHANGE TO GROUP BY
    @staticmethod
    def get_time_breakdown_since_from_uid(uid, date):
        rows = app.db.execute('''
SELECT EXTRACT(WEEK FROM time_ordered), sum(final_price)
FROM OrderItems JOIN Orders on Orders.id = OrderItems.oid                 
WHERE OrderItems.uid = :uid AND time_ordered > :date
                              GROUP BY EXTRACT(WEEK FROM time_ordered)
''',
                              uid=uid, date=date)
        ret = [['week','order total']]
        # Format for chart
        for row in rows:
            ret.append([int(row[0]), float(row[1])])
        print(ret)
        return ret

    @staticmethod
    def add(uid, oid, pid, sid, qty, status, final_price):
        try:
            rows = app.db.execute("""
INSERT INTO OrderItems(uid, oid, sid, pid, qty, status, final_price)
VALUES(:uid, :oid, :sid, :pid, :qty, :status, :final_price)
RETURNING id 
""",
                                  uid=uid, oid=oid,
                                  sid=sid,
                                  pid=pid, qty=qty,
                                  status=status,
                                  final_price=final_price)
            id = rows[0][0]
            return OrderItem.get(id)
        except Exception as e:
            print(str(e))
            return None

   
    