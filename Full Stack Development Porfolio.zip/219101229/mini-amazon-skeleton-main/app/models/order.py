from flask import current_app as app

class Order:
    def __init__(self, id, uid, time_ordered, total_price, total_quantity, order_status):
        self.id = id
        self.uid = uid
        self.time_ordered = time_ordered
        self.status = order_status
        self.total_quantity = total_quantity
        self.total_price = total_price

# Returns order given generated id
    @staticmethod
    def get(id):
        rows = app.db.execute('''
SELECT Orders.id, Orders.uid, time_ordered, sum(final_price) as total_price, sum(qty) as total_quantity,
                            CASE WHEN EXISTS(SELECT * FROM OrderItems
                            WHERE oid = :id AND status = 'placed') THEN 'unfulfilled'
                            ELSE 'fulfilled' END
                            AS order_status
FROM Orders JOIN OrderItems on Orders.id = OrderItems.oid                 
WHERE Orders.id = :id
GROUP BY Orders.id
''',
                              id=id)
        return Order(*(rows[0])) if rows else None

    @staticmethod
    def get_next_id(uid):
        rows = app.db.execute('''
SELECT max(id)
FROM Orders 
WHERE Orders.uid = :uid
''',
                              uid=uid)
        print(rows[0][0])
        return rows[0][0] if rows else None

    @staticmethod
    def get_all_from_uid(uid):
        rows = app.db.execute('''
SELECT Orders.id, Orders.uid, time_ordered, sum(final_price) as total_price, sum(qty) as total_quantity,
                            CASE WHEN EXISTS(SELECT * FROM OrderItems
                            WHERE oid = Orders.id AND status = 'placed') THEN 'unfulfilled'
                            ELSE 'fulfilled' END
                            AS order_status
FROM Orders JOIN OrderItems on Orders.id = OrderItems.oid                 
WHERE Orders.uid = :uid
GROUP BY Orders.id
ORDER BY time_ordered DESC
''',
                              uid=uid)
        return [Order(*row) for row in rows]

    @staticmethod
    def submit_order(uid, time_ordered):
        try:
            rows = app.db.execute("""
INSERT INTO Orders(uid, time_ordered)
VALUES(:uid, :time_ordered)
RETURNING id 
""",
                                  uid=uid,
                                  time_ordered=time_ordered)
            id = rows[0][0]
            return Order.get(id)
        except Exception as e:
            print(str(e))
            return None
