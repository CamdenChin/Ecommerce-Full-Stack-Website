from flask import current_app as app


class CartItem:
    def __init__(self, id, uid, sid, pid, qty, saved, price, name):
        self.id = id
        self.uid = uid
        self.sid = sid # seller id
        self.pid = pid
        self.qty = qty
        self.saved = saved
        self.price = price
        self.name = name
        self.total_price = price * qty

    def get_from_pid_and_sid(pid, sid):
        rows = app.db.execute('''
SELECT CartItems.id, uid, sid, CartItems.pid, qty, saved, price, name
FROM CartItems JOIN Sells on CartItems.pid = Sells.pid
                              JOIN Products on CartItems.pid = Products.id and
                              Sells.seller_id = CartItems.sid
WHERE CartItems.pid = :pid AND CartItems.sid = :sid;
''', pid = pid, sid = sid)
        return CartItem(*(rows[0])) if rows else None

# Returns full product info of single cart item using cart item id
    @staticmethod
    def get(id):
        rows = app.db.execute('''
SELECT CartItems.id, uid, sid, CartItems.pid, qty, saved, price, name
FROM CartItems JOIN Sells on CartItems.pid = Sells.pid
                              JOIN Products on CartItems.pid = Products.id and
                              Sells.seller_id = CartItems.sid
WHERE CartItems.id = :id;
''',
                              id=id)
        return CartItem(*(rows[0])) if rows else None

    @staticmethod
    def updatequantity(new_quantity, cart_item_id, prod_name, seller_id):
        currStock = app.db.execute('''
SELECT Sells.quantity
FROM Sells JOIN Products on Sells.pid = Products.id
WHERE Products.name = :prod_name AND Sells.seller_id = :seller_id;
''',
                              prod_name=prod_name, seller_id=seller_id)
        
        currStock = currStock[0]
        print(currStock)

        if int(new_quantity) > int(currStock[0]):
            return False

        rows = app.db.execute('''
UPDATE CartItems
SET qty = :new_quantity
WHERE id = :id;
''',
                              new_quantity=new_quantity, 
                              id = cart_item_id)
        return True

# Returns full product info of all cart items using uid
    @staticmethod
    def get_all_from_uid(uid):
        rows = app.db.execute('''
SELECT CartItems.id, uid, sid, CartItems.pid, qty, saved, price, name
FROM CartItems JOIN Sells on CartItems.pid = Sells.pid
                              JOIN Products on CartItems.pid = Products.id and
                              Sells.seller_id = CartItems.sid
WHERE uid = :uid
''',
                              uid=uid)
        return [CartItem(*row) for row in rows]

# Returns full product info of all cart items using uid
# Gets only saved items
    @staticmethod
    def get_saved_from_uid(uid):
        rows = app.db.execute('''
SELECT CartItems.id, uid, sid, CartItems.pid, qty, saved, price, name
FROM CartItems JOIN Sells on CartItems.pid = Sells.pid
                              JOIN Products on CartItems.pid = Products.id and
                              Sells.seller_id = CartItems.sid
WHERE uid = :uid AND saved = True
''',
                              uid=uid)
        return [CartItem(*row) for row in rows]
    
    @staticmethod
    def get_unsaved_from_uid(uid):
        rows = app.db.execute('''
SELECT CartItems.id, uid, sid, CartItems.pid, qty, saved, price, name
FROM CartItems JOIN Sells on CartItems.pid = Sells.pid
                              JOIN Products on CartItems.pid = Products.id and
                              Sells.seller_id = CartItems.sid
WHERE uid = :uid AND saved = False
''',
                              uid=uid)
        return [CartItem(*row) for row in rows]
    
    def update_saved(id, saved_state):
        try:
            rows = app.db.execute("""
        UPDATE CartItems
SET saved = :saved_state
WHERE id = :id;
""", id=id, saved_state=saved_state)
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def remove_from_cart(id):
        try:
            rows = app.db.execute("""
DELETE FROM CartItems
WHERE id = :id
""",
                                  id=id)
        except Exception as e:
            print(str(e))
            return None
        
    @staticmethod
    def get_cart_total(uid):
        cart_items = CartItem.get_unsaved_from_uid(uid)
        total = 0
        for item in cart_items:
            total+=item.total_price
        return total
    
   
        

# Inserts given row and generates cartitem id
    @staticmethod
    def add_to_cart(uid, pid, sid, qty):
         
        try:
            rows = app.db.execute("""
INSERT INTO CartItems(uid, sid, pid, qty, saved)
VALUES(:uid, :sid, :pid, :qty, :saved)
RETURNING id 
""",
                                  uid=uid, sid=sid,
                                  pid=pid, qty=qty, saved=False)
            id = rows[0][0]
            print(id)
            return CartItem.get(id)
        except Exception as e:
            print(str(e))
            return None
