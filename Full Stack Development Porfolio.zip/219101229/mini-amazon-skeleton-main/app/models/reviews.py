from flask import current_app as app


class ReviewItem:
    def __init__(self, id, uid, pid, sid, text, star, time_added):
        self.id = id
        self.uid = uid
        self.pid = pid
        self.sid = sid
        self.text = text
        self.star = star
        self.time_added = time_added

    

    @staticmethod
    def get(id):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM Reviews
WHERE id = :id
''',
                              id=id)
        return ReviewItem(*(rows[0])) if rows else None

    @staticmethod
    def get_all_by_uid_since(uid, since):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM Reviews
WHERE uid = :uid
AND time_added >= :since
ORDER BY time_added DESC
LIMIT 5;
''',
                              uid=uid,
                              since=since)
        return [ReviewItem(*row) for row in rows]

    @staticmethod
    def get_all_by_pid_since(pid, since):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM Reviews
WHERE pid = :pid
AND time_added >= :since
ORDER BY time_added DESC
LIMIT 5;
''',
                                pid=pid,
                                since=since)
        return [ReviewItem(*row) for row in rows]
    
    @staticmethod
    def get_all_by_sid_since(sid):
        rows = app.db.execute('''
SELECT id, uid, pid, sid, text, star, time_added
FROM Reviews
WHERE sid = :sid
LIMIT 5;
''',
                              sid=sid)
        return [ReviewItem(*row) for row in rows]

    @staticmethod
    def get_product_rating_count(pid):
        rows = app.db.execute('''
SELECT COUNT(*)
FROM Reviews
WHERE pid = :pid;
''',
                              pid=pid)
        return rows[0][0]
        

    @staticmethod
    def insert_new_review( uid, pid, sid, text, star, time_added):
        try:
            rows = app.db.execute("""
INSERT INTO Reviews(uid, pid, sid, text, star, time_added)
VALUES(:uid, :pid, :sid, :text, :star, :time_added)
RETURNING id
""",
                                    uid=uid,
                                    pid=pid,
                                    sid=sid,
                                    text=text,
                                    star=star,
                                    time_added = time_added)
            id = rows[0][0]
            return ReviewItem.get(id)
        except Exception as e:
            print(str(e))
            return None
    


    @staticmethod
    def add_new_item(uid, pid):
        try:
            rows = app.db.execute("""
INSERT INTO Reviews(uid, pid, sid)
VALUES(:uid, :pid. :sid)
RETURNING id
""",
                                  uid=uid,
                                  pid=pid,)
            id = rows[0][0]
            return ReviewItem.get(id)
        except Exception as e:
            print(str(e))
            return None
        
    @staticmethod
    def get_average_review(pid):
        try:
            rows = app.db.execute("""
SELECT AVG(star) FROM Reviews WHERE pid = :pid
""",
                pid=pid)
            return rows[0][0]
        except Exception as e:
            print(str(e))
            return None
    
    @staticmethod
    def update_review(id, text, star, time_added):
        try:
            app.db.execute("""
UPDATE Reviews
SET text = :text, star = :star, time_added = :time_added
WHERE id = :id
    """,
                        id=id,
                        text=text,
                        star=star,
                        time_added=time_added)
            return ReviewItem.get(id)
        except Exception as e:
            print(str(e))
            return None
        
    @staticmethod
    def does_exist(uid, pid, sid):
        try:
            result = app.db.execute("""
SELECT 1 FROM Reviews
WHERE uid = :uid AND pid = :pid AND sid = :sid
LIMIT 1
""",
                            uid=uid,
                            pid=pid,
                            sid=sid)
            return len(result) > 0
        except Exception as e:
            print(str(e))
            return False
    
    @staticmethod
    def delete_review(id):
        try:
            app.db.execute("""
DELETE FROM Reviews
WHERE id = :id
""",
                    id=id)
            app.db.commit()
            return True
        except Exception as e:
            print(str(e))
            return False
        
