from flask import current_app as app


class SellerHistory:
    def __init__(self, id, oid, uid, sid, pid, qty, final_price, status, name, time_ordered, firstname, lastname, address, email ):
        self.id = id
        self.oid = oid
        self.uid = uid
        self.sid = sid # seller id
        self.pid = pid
        self.qty = qty
        self.final_price = final_price
        self.status = status
        self.name = name
        self.time_ordered = time_ordered
        self.firstname = firstname
        self.lastname = lastname
        self.address = address
        self.email = email

    @staticmethod
    def get_orderitems_by_seller_id(sid, page):
        rows = app.db.execute('''
SELECT OrderItems.id, OrderItems.oid, OrderItems.uid, sid, pid, qty, final_price, status, name, time_ordered, firstname, lastname, address, email
FROM OrderItems JOIN Products on OrderItems.pid = Products.id
JOIN Users on OrderItems.uid = Users.id
JOIN Orders on OrderItems.oid = Orders.id
WHERE OrderItems.sid = :sid
ORDER BY time_ordered DESC
LIMIT 15 OFFSET :page;
''',
                              sid=sid,
                              page=page)
        return [SellerHistory(*row) for row in rows]

    @staticmethod
    def mark_item_fulfilled(id):
        app.db.execute('''
UPDATE OrderItems
SET status = 'fulfilled'
WHERE OrderItems.id = :id
''',
                       id=id)
        return True


class SellerBuyerAnalytics:
    def __init__(self, numOrders, totalSpend, avgSpend, topProducts):
        self.numOrders = numOrders
        self.totalSpend = totalSpend
        self.avgSpend = avgSpend
        self.topProducts = topProducts

    @staticmethod
    def get_analytics(sid, buyer_id):
        statRows = app.db.execute('''
SELECT COUNT(DISTINCT oid) as numOrders, SUM(final_price) as totalSpend, AVG(final_price) as avgSpend
FROM OrderItems
WHERE sid = :sid AND uid = :buyer_id
GROUP BY uid
''',
                                  sid=sid,
                                  buyer_id=buyer_id)

        topProducts = app.db.execute('''
SELECT Products.name, SUM(OrderItems.qty) AS totalQty
FROM OrderItems
JOIN Products ON OrderItems.pid = Products.id
WHERE OrderItems.sid = :sid AND OrderItems.uid = :buyer_id
GROUP BY Products.name
ORDER BY totalQty DESC
LIMIT 5;
''',
                                     sid=sid,
                                     buyer_id=buyer_id)

        print(statRows, topProducts)
                                    
        stats = SellerBuyerAnalytics(statRows[0][0], round(float(statRows[0][1]), 2), round(float(statRows[0][2]), 2), topProducts)

        return stats


