from flask import current_app as app


class Product:
    def __init__(self, id, name, description, category, image_url, price=0, seller_id=None):
        self.id = id
        self.name = name
        self.description = description
        self.category = category
        self.image_url = image_url
        self.price = price
        self.seller_id = seller_id
    
    @staticmethod
    def get_product_name(id):
        rows = app.db.execute('''
SELECT name
FROM Products
WHERE id = :id
''',
                                id=id)
        return rows[0][0] if rows is not None else None
        


    @staticmethod
    def get_price(id):
        rows = app.db.execute('''
SELECT price
FROM Products
WHERE id = :id
''',
                              id=id)
        return rows[0] if rows is not None else None

    @staticmethod
    def get(id):
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
WHERE id = :id
''',
                              id=id)
        return Product(*(rows[0])) if rows is not None else None

    @staticmethod
    def get_all():
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
''')
        return [Product(*row) for row in rows]

    @staticmethod
    def get_product(name): 
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
WHERE name like :name OR description like :name OR category like :name
''',
                             name = name)
        return [Product(*row) for row in rows]
        
    @staticmethod
    def get_product_with_category(name, category): 
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
WHERE category = :category AND name like :name OR category = :category AND description like :name 
''',
                             name = name, 
                             category = category)
        return [Product(*row) for row in rows]

    @staticmethod
    def get_product_with_price_sorting(name, pricesort): 
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
WHERE category = :category AND name like :name OR category = :category AND description like :name 
ORDER BY price :pricesort
''',
                             name = name, 
                             category = category)
        return [Product(*row) for row in rows]
    @staticmethod
    def get_product_with_category_and_price_sorting(name, category, pricesort): 
        rows = app.db.execute('''
SELECT id, name, description, category, image_url
FROM Products
WHERE category = :category AND name like :name OR category = :category AND description like :name 
ORDER BY price :pricesort
''',
                             name = name, 
                             category = category,
                             pricesort = pricesort)
        return [Product(*row) for row in rows]

    @staticmethod
    def display_k_page(k, num, name="", category="", pricesort="", pricelim = ""):
        # Initialize the base query with JOIN and MIN aggregation
        query = '''
    SELECT Products.id, Products.name, Products.description, Products.category, Products.image_url, MIN(Sells.price) AS min_price
    FROM Products 
    JOIN Sells ON Products.id = Sells.pid 
    '''

        # Initialize a dictionary to hold query parameters
        params = {
            'k': k,
            'num': num,
            'pricelim': pricelim
        }

        # Conditions to be added to WHERE clause
        conditions = []

        # Add conditions based on provided parameters
        if name:
            conditions.append("LOWER(Products.name) LIKE LOWER(:name)")
            params['name'] = f'%{name}%'
        if category and category != 'none':
            conditions.append("Products.category = :category")
            params['category'] = category

        # Append conditions to query
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)

        # Group by product fields to aggregate prices
        query += ' GROUP BY Products.id, Products.name, Products.description, Products.category, Products.image_url'

        if pricelim and pricelim != 'none':
            try:
                pricelim = float(pricelim)  # Ensure pricelim is a valid number
                query += ' HAVING MIN(Sells.price) < :pricelim'
                params['pricelim'] = pricelim
            except ValueError:
                # Handle the case where pricelim is not a valid number
                print("Invalid price limit")

        # Add ORDER BY clause
        if pricesort in ['ASC', 'DESC']:
            query += ' ORDER BY min_price ' + pricesort
        else:
            query += ' ORDER BY Products.id'

            

        # Add LIMIT and OFFSET
        query += ' LIMIT :num OFFSET (:k - 1) * :num'

        print(query)

        # Execute the query
        rows = app.db.execute(query, **params)

        return [Product(*row) for row in rows]



    @staticmethod
    def add_product(name, description, category, image_url):
        try: 
            rows = app.db.execute('''
INSERT INTO Products (name, description, category, image_url)
VALUES (:name, :description, :category, :image_url)
''',
                              name = name,
                              description = description,
                              category = category,
                              image_url = image_url)
        except:
            return False
        
        # get the id of the product just added
        rows = app.db.execute('''
SELECT id
FROM Products
WHERE name = :name AND description = :description AND image_url = :image_url
''',
                              name = name,
                              description = description,
                              image_url = image_url)

        return rows[0][0] if rows is not None else None

    @staticmethod
    def get_average_review(pid):
        try:
            rows = app.db.execute("""
SELECT AVG(star) FROM Reviews WHERE pid = :pid
""",
                pid=pid)
            return rows[0][0]
        except Exception as e:
            print(str(e))
            return None


class ProductAnalytics:
    def __init__(self, year, month, number_of_orders):
        self.year = year
        self.month = month
        self.number_of_orders = number_of_orders
    
    @staticmethod
    def get_analytics(pid, sid):
        try:
            rows = app.db.execute("""
SELECT 
    EXTRACT(YEAR FROM o.time_ordered) AS order_year,
    EXTRACT(MONTH FROM o.time_ordered) AS order_month,
    SUM(oi.qty) AS total_quantity_sold
FROM 
    Orders o
JOIN 
    OrderItems oi ON o.id = oi.oid
WHERE 
    oi.pid = :pid AND oi.sid = :sid
GROUP BY 
    order_year, order_month
ORDER BY 
    order_year, order_month;
""",
                pid=pid, sid=sid)
            output = []
            for row in rows:
                output.append((int(row[0]), int(row[1]), int(row[2])))
            return output
        except Exception as e:
            print(str(e))
            return None