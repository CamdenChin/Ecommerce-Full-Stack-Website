from flask import render_template
from flask_login import current_user
from flask import jsonify

from flask import redirect, url_for

import datetime

from humanize import naturaltime

from .models.wishlist import WishlistItem

from flask import Blueprint, redirect, url_for
bp = Blueprint('wishlist', __name__)

@bp.route('/wishlist')
def wishlist():
    # get all wishlist items from certain date:

    if current_user.is_authenticated:
        items = WishlistItem.get_all_by_uid_since(
            current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        return render_template('wishlist.html',
                      items=items,
                      humanize_time=humanize_time)
    else:
        items = None
        return jsonify({}), 404
   
@bp.route('/wishlist/add/<int:product_id>', methods=['POST'])
def wishlist_add(product_id):
    if current_user.is_authenticated:
        WishlistItem.addToList(current_user.id, product_id, datetime.datetime.now())
        return redirect(url_for('wishlist.wishlist'))
    else:
        return jsonify({}), 404

def humanize_time(dt):
    return naturaltime(datetime.datetime.now() - dt)
