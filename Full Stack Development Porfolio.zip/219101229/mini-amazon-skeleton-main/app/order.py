from flask import render_template, flash
from flask_login import current_user
from flask import jsonify
import datetime

from flask_wtf import FlaskForm
from wtforms import SubmitField


from .models.order import Order
from .models.orderitem import OrderItem
from .models.cart import CartItem
from .models.user import User
from .models.sells import Sells

import datetime
from humanize import naturaltime

from flask import Blueprint, redirect, url_for, request
bp = Blueprint('order', __name__)


@bp.route('/orders')
def orders():
    if current_user.is_authenticated:
        items = Order.get_all_from_uid(
            current_user.id)
        return render_template('orders.html',
                      items=items,
                      humanize_time=humanize_time)
    else:
        items = None
        return jsonify({}), 404

@bp.route('/submit_order', methods=['POST'])
def submit_order():
    if current_user.is_authenticated:
        submit_message = ""
        # Submit orders from backend entirely, grabbing user's cart
        user_id = request.form.get('user_id')
        ordered_items = CartItem.get_unsaved_from_uid(user_id)
        cart_total = CartItem.get_cart_total(user_id)
        # Check 1: quantity
        if len(ordered_items) == 0:
            flash('No items in Cart', "Error")
            return redirect(url_for('cart.cart'))
        # Check 2: price
        if cart_total > User.getBalance(user_id):
            flash('Insufficient Balance', "Error")
            return redirect(url_for('cart.cart'))
        # Check 3: stock
        invalid = False
        for item in ordered_items:
            stock = Sells.get_by_seller_id_and_product_id(item.sid, item.pid).quantity
            if item.qty > stock:
                invalid = True
                flash(f"Insufficient Stock for {item.name} from seller {item.sid}", "Error")
        if invalid: return redirect(url_for('cart.cart'))
        # If pass all checks, create order and create an order item for each cart item
        Order.submit_order(current_user.id, datetime.datetime.now())
        new_id = Order.get_next_id(user_id)
        for item in ordered_items:
            OrderItem.add(user_id, new_id, item.pid, item.sid, item.qty, "placed", item.total_price)
            CartItem.remove_from_cart(item.id)
            # Update stock
            Sells.submit_order_by_seller_id_and_product_id(item.sid, item.pid, item.qty)
            # Update seller balance
            User.edit_balance(item.total_price, item.sid)
        User.edit_balance(-1 * cart_total, current_user.id)
        return redirect(url_for('order.orders'))
    else:
        # if user not logged in, 404 error
        items = None
        return jsonify({}), 404
    
def humanize_time(dt):
    return naturaltime(datetime.datetime.now() - dt)