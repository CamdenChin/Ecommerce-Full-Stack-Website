from flask import render_template, flash
from flask_login import current_user
from flask import jsonify
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
import datetime

from .models.cart import CartItem
from .models.sells import Sells


from flask import Blueprint, redirect, url_for, request
bp = Blueprint('cart', __name__)

class QuantityForm(FlaskForm): 
    new_quantity = StringField('Change Quantity of Item: ')
    submit = SubmitField('Update Quantity')


@bp.route('/cart/')
def cart():

    # return template displaying all cart items for this user
    
    new_quantity = request.args.get('new_quantity', default="")
    quantityform = QuantityForm(formdata=request.args)
    quantityform.new_quantity.data = new_quantity

    if current_user.is_authenticated:

        items = CartItem.get_unsaved_from_uid(
            current_user.id)
        saved = CartItem.get_saved_from_uid(current_user.id)
        total = CartItem.get_cart_total(current_user.id)
        return render_template('cart.html',
                      items=items,
                      saved=saved,
                      total=total,
                      user_id = current_user.id, 
                      quantityform = quantityform)
    else:
        # if user not logged in, 404 error
        return redirect(url_for('login.login'))

@bp.route('/cart/changequantity/<int:cart_item_id>/<string:prod_name>/<int:seller_id>', methods=['POST'])  
def changequantity(cart_item_id, prod_name, seller_id):
    new_quantity = request.form.get('new_quantity', default="")
    
    if not new_quantity.isdigit() or int(new_quantity) < 0:
        return redirect(url_for('cart.cart'))
    
    if current_user.is_authenticated:
        if CartItem.updatequantity(new_quantity, cart_item_id, prod_name, seller_id) == False:
            flash(f"Insufficient Stock", "Error")
            return redirect(url_for('cart.cart'))
        flash(f"Updated quantity to be: " + str(new_quantity), "Success")
        return redirect(url_for('cart.cart'))
    else:
        return jsonify({}), 404

@bp.route('/cart/remove/<int:cart_item_id>', methods=['POST'])  
def cart_remove(cart_item_id):
    if current_user.is_authenticated:
        CartItem.remove_from_cart(cart_item_id)
        flash(f"Removed from cart", "Success")
        return redirect(url_for('cart.cart')) # send back to cart? refresh?
    else:
        return jsonify({}), 404

@bp.route('/cart/save/<int:cart_item_id>', methods=['POST'])  
def cart_save(cart_item_id):
    if current_user.is_authenticated:
        CartItem.update_saved(cart_item_id, True)
        flash(f"Moved to Saved", "Success")
        return redirect(url_for('cart.cart')) # send back to cart? refresh?
    else:
        return jsonify({}), 404

@bp.route('/cart/unsave/<int:cart_item_id>', methods=['POST'])  
def cart_unsave(cart_item_id):
    if current_user.is_authenticated:
        CartItem.update_saved(cart_item_id, False)
        flash(f"Moved to Cart", "Success")
        return redirect(url_for('cart.cart')) # send back to cart? refresh?
    else:
        return jsonify({}), 404

# URL format: take in parm from form in product_detail.html
@bp.route('/cart/add', methods=['POST'])
def cart_add():
    product_id = request.form.get('product_id')
    seller_id = request.form.get('seller_id')
    quantity = request.form.get('quantity')
    print(type(quantity))

    

    new_quantity = request.args.get('new_quantity', default="")
        
    quantityform = QuantityForm(formdata=request.args)
    quantityform.new_quantity.data = new_quantity
    # take in product id, seller id, and quantity
    if current_user.is_authenticated:
        
        # Check: nonzero and numeric quantity
        if not quantity.isdigit() or int(quantity) <= 0:
            flash(f"Invalid Quantity", "Error")
            return redirect(url_for('product.product', product_id=product_id))
        # Check: check stock
        stock = Sells.get_by_seller_id_and_product_id(seller_id, product_id).quantity
        if stock < int(quantity):
            flash(f"Insufficient Stock", "Error")
            return redirect(url_for('product.product', product_id=product_id))
        # Check: check if already in cart
        if CartItem.get_from_pid_and_sid(product_id, seller_id):
            flash(f"Item from Seller Already in Cart", "Error")
            return redirect(url_for('product.product', product_id=product_id))
        CartItem.add_to_cart(current_user.id, product_id, seller_id, quantity)
        flash(f"Added product {product_id} to cart", "Success")
        return redirect(url_for('cart.cart'))
    else:
        return jsonify({}), 404
