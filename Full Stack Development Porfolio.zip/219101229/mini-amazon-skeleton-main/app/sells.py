from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for
import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField

from .models.sells import Sells


from flask import Blueprint
bp = Blueprint('sells', __name__)



# Gets all available products for sale by seller
@bp.route('/sells/<int:seller_id>', methods=['GET'])
def sells(seller_id):
    if current_user.is_authenticated:
        products = Sells.get_all_by_seller_id(
            seller_id=seller_id
        )
        return render_template('products_by_seller.html',
                        products=products,
                        seller_id = seller_id)
    else:
        products = None
    return jsonify({}), 404





