from flask import render_template
from flask_login import current_user
from flask import jsonify
import datetime

from .models.product import Product
from .models.sells import Sells
from .models.reviews import ReviewItem

from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField

from flask import Blueprint, redirect, url_for
bp = Blueprint('product', __name__)

class CartForm(FlaskForm):
    #Seller search
    quantity = StringField('Quantity')
    submit = SubmitField('Add to Cart')

@bp.route('/product/<int:product_id>')
def product(product_id):
    # return template displaying all cart items for this user
    cartform = CartForm()

    # Finds product by seller id, redirects to sells url

    if current_user.is_authenticated:
        product = Product.get(product_id)
        sells = Sells.get_by_product_id(product_id)
        reviews = ReviewItem.get_all_by_pid_since(
            product_id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        review_count = ReviewItem.get_product_rating_count(product_id)
        return render_template('product_detail.html',
                      product = product,
                      sells = sells,
                      cartform = cartform,
                      reviews = reviews,
                      get_item_name = get_item_name,
                      review_count = review_count,
                      auth = True)
    else:
        product = Product.get(product_id)
        sells = Sells.get_by_product_id(product_id)
        return render_template('product_detail.html',
                      product = product,
                      sells = sells,
                      cartform = cartform,
                      auth = False)

def get_item_name(pid):
        return Product.get_product_name(pid)
   
