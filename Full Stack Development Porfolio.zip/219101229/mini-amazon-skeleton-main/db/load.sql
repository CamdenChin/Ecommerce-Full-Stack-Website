\COPY Users FROM 'Users.csv' WITH DELIMITER ',' NULL '' CSV
-- since id is auto-generated; we need the next command to adjust the counter
-- for auto-generation so next INSERT will not clash with ids loaded above:
SELECT pg_catalog.setval('public.users_id_seq',
                         (SELECT MAX(id)+1 FROM Users),
                         false);

\COPY Products FROM 'Products.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.products_id_seq',
                         (SELECT MAX(id)+1 FROM Products),
                         false);

\COPY Wishes FROM 'Wishes.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.wishes_id_seq',
                         (SELECT MAX(id)+1 FROM Wishes),
                         false);


\COPY Sellers FROM 'Sellers.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.sellers_id_seq',
                         (SELECT MAX(id)+1 FROM Sellers),
                         false);

\COPY CartItems FROM 'CartItems.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.cartitems_id_seq',
                         (SELECT MAX(id)+1 FROM CartItems),
                         false);

\COPY Sells FROM 'Sells.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.sells_id_seq',
                         (SELECT MAX(id)+1 FROM Sells),
                         false);

\COPY Orders FROM 'Orders.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.orders_id_seq',
                         (SELECT MAX(id)+1 FROM Orders),
                         false);

\COPY OrderItems FROM 'OrderItems.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.orderitems_id_seq',
                         (SELECT MAX(id)+1 FROM OrderItems),
                         false);


\COPY Reviews FROM 'Reviews.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.reviews_id_seq',
                         (SELECT MAX(id)+1 FROM Reviews),
                         false);

\COPY SellerReviews FROM 'SellerReviews.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.sellerreviews_id_seq',
                         (SELECT MAX(id)+1 FROM SellerReviews),
                         false);


\COPY GiftCards FROM 'GiftCards.csv' WITH DELIMITER ',' NULL '' CSV
SELECT pg_catalog.setval('public.giftcards_id_seq',
                         (SELECT MAX(id)+1 FROM GiftCards),
                         false);




