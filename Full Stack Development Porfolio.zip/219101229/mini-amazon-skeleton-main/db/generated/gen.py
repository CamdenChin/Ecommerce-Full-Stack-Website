from werkzeug.security import generate_password_hash
import csv
from faker import Faker
import random
import uuid

num_users = 100
num_products = 500
num_purchases = 5000
num_sellers = 10

Faker.seed(0)
fake = Faker()


def get_csv_writer(f):
    return csv.writer(f, dialect='unix')

def generate_random_price(maxPrice = 1000):
    price = random.randint(0, maxPrice) + random.random()
    price = round(price, 2)
    return price

def generate_random_timestamp():
    timestamp = fake.date_time_this_decade()
    formatted_timestamp = timestamp.strftime("%Y-%m-%d %H:%M:%S")
    return formatted_timestamp

def gen_users(num_users):
    with open('Users.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Users...', end=' ', flush=True)
        for uid in range(num_users):
            if uid % 10 == 0:
                print(f'{uid}', end=' ', flush=True)
            profile = fake.profile()
            email = profile['mail']
            plain_password = f'pass{uid}'
            password = generate_password_hash(plain_password)
            name_components = profile['name'].split(' ')
            firstname = name_components[0]
            lastname = name_components[-1]
            address = profile['address']
            balance = fake.random_int(min=0, max=1000)
            image = 'https://t4.ftcdn.net/jpg/00/64/67/63/360_F_64676383_LdbmhiNM6Ypzb3FM4PPuFP9rHe7ri8Ju.jpg'
            if uid == 0:
                print(f'uid: {uid}, email: {email}, password: {plain_password}, firstname: {firstname}, lastname: {lastname}, address: {address}, balance: {balance}')
            writer.writerow([uid, email, password, firstname, lastname, address, balance, image])
        print(f'{num_users} generated')
    return


def gen_products(num_products):
    unique_names = set()
    with open('Products.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Products...', end=' ', flush=True)
        for pid in range(num_products):
            if pid % 100 == 0:
                print(f'{pid}', end=' ', flush=True)
            name = fake.sentence(nb_words=4)[:-1]
            while name in unique_names:  # Ensure uniqueness
                name = fake.sentence(nb_words=4)[:-1]
            unique_names.add(name)
            description = fake.sentence(nb_words=6)
            category = fake.random_element(elements=('Electronics', 'Clothing', 'Books', 'Sports', 'Home', 'Beauty', 'Toys', 'Outdoors'))
            image_url = f"https://picsum.photos/seed/{(pid % 6) + 1}/300/300"
            writer.writerow([pid, name, description, category, image_url])
        print(f'{num_products} generated;')
    return


def gen_sellers(num_sellers):
    with open('Sellers.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Sellers...', end=' ', flush=True)
        current_sellers = [0]
        for sid in range(num_sellers):
            user_id = fake.random_int(min=0, max=num_users-1)
            while user_id in current_sellers:
                user_id = fake.random_int(min=0, max=num_users-1)
            current_sellers.append(user_id)
            average_rating = fake.random_int(min=0, max=5)
            writer.writerow([sid, user_id, average_rating])
        writer.writerow([num_sellers, 0, 0])
        print(f'{num_sellers} generated')
    return current_sellers

def gen_sells(seller_ids):
    sells = {}
    with open('Sells.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Sells...', end=' ', flush=True)

        current_pairs = set()

        for pid in range(num_products):
            # Iterate through anywhere from 1 to 10 random unique seller_ids
            randInt = fake.random_int(min=1, max=10)
            for sid in random.sample(seller_ids, randInt):
                quantity = fake.random_int(min=0, max=100)
                price = generate_random_price()
                current_pairs.add((sid, pid))
                sells[sid] = sells.get(sid, []) + [(pid)]
                writer.writerow([pid, sid, pid, quantity, price])

        print(f'Sells generated')
    return sells

def gen_wishes():
    with open('Wishes.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Wishes...', end=' ', flush=True)
        for wid in range(fake.random_int(min=num_users, max=num_users*2)):
            user_id = fake.random_int(min=0, max=num_users-1)
            product_id = fake.random_int(min=0, max=num_products-1)
            timestamp = generate_random_timestamp()
            writer.writerow([wid, user_id, product_id, timestamp])
        print(f'Wishes generated')
    return

def gen_reviews():
    with open('Reviews.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Reviews...', end=' ', flush=True)
        for rid in range(fake.random_int(min=num_users, max=num_users*2)):
            user_id = fake.random_int(min=0, max=num_users-1)
            product_id = fake.random_int(min=0, max=num_products-1)
            seller_id = fake.random_element(elements=seller_ids)
            text = fake.sentence(nb_words=5)
            star = generate_random_price(5)
            timestamp = generate_random_timestamp()
            writer.writerow([rid, user_id, product_id, seller_id, text, star, timestamp])
        print(f'Reviews generated')

def gen_sellerreviews(seller_ids):
    with open('SellerReviews.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('SellerReviews...', end=' ', flush=True)
        for rid in range(num_users * 2):
            user_id = fake.random_int(min=0, max=num_users-1)
            seller_id = fake.random_element(elements=seller_ids)
            product_id = fake.random_int(min=0, max=num_products-1)
            text = fake.sentence(nb_words=5)
            email = fake.email()
            star = generate_random_price(5)
            timestamp = generate_random_timestamp()
            writer.writerow([rid, user_id, product_id, seller_id, text, star, timestamp])
            if rid % 10 == 0:
                print(f'{rid}', end=' ', flush=True)
        print(f'SellerReviews generated')

def gen_cartitems(seller_ids):
    with open('CartItems.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('CartItems...', end=' ', flush=True)
        for cid in range(num_users * 3):
            user_id = fake.random_int(min=0, max=num_users-1)
            seller_id = fake.random_element(elements=seller_ids)
            product_id = fake.random_int(min=0, max=num_products-1)
            quantity = fake.random_int(min=1, max=5)
            saved = fake.random_element(elements=(True, False))
            writer.writerow([cid, user_id, seller_id, product_id, quantity, saved])
        print(f'CartItems generated')

def gen_orders():
    with open('Orders.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('Orders...', end=' ', flush=True)
        for oid in range(num_users * 3):
            user_id = fake.random_int(min=0, max=num_users-1)
            timestamp = generate_random_timestamp()
            writer.writerow([oid, user_id, timestamp])
        print(f'Orders generated')

def gen_orderitems(seller_ids, sells):
    with open('OrderItems.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('OrderItems...', end=' ', flush=True)
        idx = 0
        for seller_id in seller_ids:
            for product_id in sells[seller_id]:
                for oiid in range(fake.random_int(min=1, max=10)):
                    oid = fake.random_int(min=0, max=num_users*3-1)
                    user_id = fake.random_int(min=0, max=num_users-1)
                    quantity = fake.random_int(min=1, max=5)
                    status = fake.random_element(elements=('placed', 'fulfilled'))
                    final_price = generate_random_price()
                    writer.writerow([idx, oid, user_id, seller_id, product_id, quantity, status, final_price])
                    idx += 1

def gen_giftcards():
    with open('GiftCards.csv', 'w') as f:
        writer = get_csv_writer(f)
        print('GiftCards...', end=' ', flush=True)
        for gid in range(num_users):
            user_id = fake.random_int(min=0, max=num_users-1)
            cardNumber = str(uuid.uuid4())
            amount = generate_random_price(1000)
            writer.writerow([gid, cardNumber, amount, False, user_id])
        print(f'GiftCards generated')

gen_users(num_users)
gen_products(num_products)
seller_ids = gen_sellers(num_sellers)
sells = gen_sells(seller_ids)
gen_wishes()
gen_reviews()
gen_sellerreviews(seller_ids)
gen_cartitems(seller_ids)
gen_orders()
gen_orderitems(seller_ids, sells)
gen_giftcards()